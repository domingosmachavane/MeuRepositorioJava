
package principal;

import principal.Pessoa;

public class Medico extends Pessoa{
    //Atributos
    private String especializacao;
    private int numMedico;
    private int senha;
    //Construtores
    public Medico(int id,String nome, String dataNas, String morada, String bi, int celular, char sexo, String espec, int numMedico, int senha){
        super(id,nome, dataNas, morada, bi, celular, sexo);
        this.especializacao = espec;
        this.numMedico = numMedico;
        this.senha = senha;
    }

    public Medico(){
        this(0,"", "", "", "", 0, ' ', "", 0,0);
    }
    
    /*GETTER*/
    public int getNumMedico() {
        return numMedico;
    }

    public int getSenha() {
        return senha;
    }
    
    //Metodo Acessor de informacao*
    public String toString(){
        return
                super.toString()+
                "Especializaco.........................: "+ especializacao + "\n"+
                "Numero Medico.........................: "+numMedico+"\n"+
                "................................................................"+
                "\n";
    }
}
