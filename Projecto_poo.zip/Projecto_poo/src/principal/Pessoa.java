
package principal;
import java.io.Serializable;
public class Pessoa implements Serializable{
    /*ATRIBUTOS DA CLASSE*/
    protected String nome,dataNascimento,morada , bi;
    protected int id,celular;
    protected char sexo;
    
    /*CONSTRUTORES*/
    public Pessoa(int id,String nome, String dataNas, String morada, String bi, int celular, char sexo){
        this.id=id;
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.morada = morada;
        this.bi = bi;
        this.celular = celular;
        this.sexo = sexo;
    }
    public Pessoa(){
        this(0, "", "", "", "", 0, ' ');
    }
    
    public int getId(){
      return id;  
    }
    /*METODO PARA ACESSAR A INFORMACAO DA CLASSE*/
    public String toString(){
        return
                "Nome..................................: "+nome +"\n"+
                "Data de nascimento....................: "+dataNascimento +"\n"+
                "Sexo..................................: "+sexo+"\n"+
                "BI....................................: "+bi +"\n"+ 
                "Morada................................: "+morada+"\n"+
                "Numero de Celular.....................: "+celular+"\n";
    }
}
