package principal;

import java.util.Vector;

public class Tarefas {

    //Atributos
    private Vector dados, setor;
    private Valida v;

    //Construtores
    public Tarefas() {
        dados = new Vector();
        v = new Valida();
    }

    /*METODOS ESPECIFICOS*/
    //Metodo para Adicionar
    public void adicionarInformacao(int op) {
        Pessoa pessoa;
        String nome, dataNas, morada, bi, especializacao;
        int celular, id, senha;
        char sexo;
        System.out.println("******INTRODUZINDO DADOS******");
        if(dados.isEmpty()){
            id = 1;
            }
        else{
            int ultimo_indice = dados.size() - 1;
            pessoa = (Pessoa) dados.elementAt(ultimo_indice);
            id = pessoa.getId()+1;
        }
        
        nome = v.validaString("Nome: ", 3, 100);
        dataNas = v.validaData("Data de Nascimento (formato: DD/MM/ANO): ");
        morada = v.validaString("Morada: ", 3, 1000);
        bi = v.validaString("BI: ", 4, 20);
        celular = v.validaInt("Numero de celular: ", 82, 999999999);
        sexo = v.validaChar("Sexo (f/m): ");
        senha = v.validaInt("Senha(1111-9999): ", 1000, 9999);
        /*OP-> OPCAO: 1 INDICA ADICIONAR PACIENTE, 2 INDICA ADICIONAR MEDICO, 3 INDICA ADICIONAR ADMINISTRADOR*/
        if (op == 1) {
            pessoa = new Paciente(id, nome, dataNas, morada, bi, celular, sexo);
            dados.addElement(pessoa);
        } else if (op == 2) {
            especializacao = v.validaString("Especializacao: ", 3, 100);
            pessoa = new Medico(id,nome, dataNas, morada, bi, celular, sexo, especializacao, id, senha);
            dados.addElement(pessoa);
        } else if (op == 3) {
            pessoa = new Administrador(id, nome, dataNas, morada, bi, celular, sexo, id, senha);
            dados.addElement(pessoa);
        }
        dados.trimToSize();
        gravarObj();//Para Gravar Automaticamente cada Objecto
    }
    

    //Login//para ENTRAR NO MENU PRINCIPAL
    public int entrar() {
        Pessoa pessoa;
      //  boolean verificaExistir = false;
        int id, senha;
        System.out.println("Digite o ID: ");
        id = v.validaInt("", 0, 9999);
        senha = v.validaInt("Digite a senha  ", 1111, 9999);
        if(id == 1234 && senha == 1234){
            return 1;
        }
        for (int i = 0; i < dados.size(); i++) {
            pessoa = (Pessoa) dados.elementAt(i);
            if (pessoa instanceof Administrador) {
                if (((Administrador) pessoa).getNumAdministrador() == id && ((Administrador) pessoa).getSenha() == senha) {
                    return 1;
                }
            } else {
                if (pessoa instanceof Medico) {
                    if (((Medico) pessoa).getNumMedico() == id && ((Medico) pessoa).getSenha() == senha) {
                        return 2;
                    }
                }
            }

        }
        
        return 0;
    }

    public void showInfo(int op) {
        Pessoa aux;
        for (int i = 0; i < dados.size(); i++) {
            aux = (Pessoa) dados.elementAt(i);
            if (op == 1) {
                int cont = 1;
                if (aux instanceof Paciente) {
                    System.out.println(cont + "-o Paciente: \n" + aux.toString());
                    cont++;
                }
            } else {
                if (op == 2) {
                    int cont1 = 1;
                    if (aux instanceof Medico) {
                        System.out.println(cont1 + "-o Medico: \n" + aux.toString());
                        cont1++;
                    }
                }
            }
        }
    }

    /*Metodos que Invoca a classe Ficheiros para acessar aos Metodos gravar e ler ficheiro*/
    //METODO PARA GRAVAR Obj
    public void gravarObj() {
        Ficheiros fich = new Ficheiros();
        fich.gravarObj(dados);
    }

    //METODO PARA LER OBJ
    public void lerObj() {
        Ficheiros fich = new Ficheiros();
        dados = fich.lerObj();
    }
}
