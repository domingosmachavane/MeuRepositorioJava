package principal;
import java.io.*;
import java.util.Vector;
import java.util.StringTokenizer;
public class Ficheiros {
    //Atributos
    private String nomeFichObj;
    //Construtor
    public Ficheiros(){
        nomeFichObj = "DadosObjecto.dat";
    }
    
    //Metodo para Gravar no ficheio de objecto
    public void gravarObj(Vector x){
        try{
            FileOutputStream fos = new FileOutputStream(nomeFichObj);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(x);
            oos.close();
        }catch(IOException io){System.out.println(io.getMessage());}
    }
    
    /*METODO PARA LER DADOS DO FICHEIRO DE OBJECTOS,
      O TIPO DE RETORNO SERA UM VECTOR JA PREENCHIDO
      COM A INFORMACAO PREVIAMENTE GRAVADA*/
    public Vector lerObj(){
        Vector x = new Vector();
        try{
            FileInputStream fin = new FileInputStream(nomeFichObj);
            ObjectInputStream oin = new ObjectInputStream(fin);
            x = (Vector)oin.readObject();
            oin.close();
        }catch(FileNotFoundException fnf){System.out.println("Ficheiros de Objectos nao encontrado: "+fnf.toString());
        }catch(ClassNotFoundException cnf){System.out.println("Classe nao encontrada! "+cnf.getException());
        }catch(IOException io){System.out.println(io.getMessage());}
        return x;
    }
    
    /*METODOS PARA FICHEIROS DE TEXTO*/
    public void lerFich(String nomeFich, Vector x){
        int id, senha, celular;
        StringTokenizer umaCadeia;
        String umaL = "";
        try{
            BufferedReader br = new BufferedReader( new FileReader(nomeFich));
            umaL = br.readLine();
            while(umaL != null){
                umaCadeia = new StringTokenizer(umaL, ";");
                id = Integer.parseInt(umaCadeia.nextToken());
                senha = Integer.parseInt(umaCadeia.nextToken());
                
            }
        }catch(FileNotFoundException fn){System.out.println("File Nao foi encontrado!");
        }catch(IOException io){System.out.println(io.getMessage());}
        
    }
}
