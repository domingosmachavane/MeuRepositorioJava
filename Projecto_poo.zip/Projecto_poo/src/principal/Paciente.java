
package principal;

import principal.Pessoa;

public class Paciente extends Pessoa {
    /*ATRIBUTOS*/
    private int numPaciente;
    
    //Construtores
    public Paciente(int id,String nome, String dataNas, String morada, String bi, 
            int celular, char sexo){
        super(id,nome, dataNas, morada, bi, celular, sexo);
        //this.numPaciente = numPac;
    }
    public Paciente(){
        this(0,"", "", "", "", 0,' ');
    }
    
    /*GETTER*/
    public int getNumPaciente() {
        return numPaciente;
    }
    
    /*Metodo para Retornar Informacao*/
    public String toString(){
        return super.toString()+
                "Numero Paciente ......................: "+numPaciente+
                "\n................................................................."+"\n"+
                "\n";
    }
}
