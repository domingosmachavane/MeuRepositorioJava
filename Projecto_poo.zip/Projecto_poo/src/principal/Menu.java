
package principal;

public class Menu {
    private Valida v;
    private Tarefas a;
    
    public Menu(){
        v = new Valida();
        a = new Tarefas();
        a.lerObj();
    }
    
    public void ApresentarMenu(){
        int verificaExistir ;
        do{
            verificaExistir=a.entrar();
            if(verificaExistir==0){
                System.out.println("Senha Errada ou ID Errada! Verique Correctamente");
            }
            else if(verificaExistir == 1){
                menuAdmin();
            }
            else if( verificaExistir == 2){
                menuMedico();
            }
        }while(verificaExistir==0);
    }
    
    // MENU ADMINISTRADOR
    private void menuAdmin(){
        int op = 0;
        do{
            System.out.println("**********BEM VINDO AO SISTEMA DE GESTAO*************");
            System.out.println("1.  Adicionar Administrador.\n"
                    + "2. Visualizar Administradores.\n"
                    + "3. Adicionar Medico.\n"
                    + "4. Alterar Dados Medico.\n"
                    + "5. Visualizar Medicos.\n"
                    + "7. Sair.\n");
            op = v.validaInt("Escolha Opcao [1-5]: ", 1, 7);
            
            switch(op){
                case 1: a.adicionarInformacao(3);break;
                case 2: a.showInfo(3); break;
                case 3: a.adicionarInformacao(2);break;
                case 5: a.showInfo(2);break;
                case 7: System.exit(0);break;
            }
        }while(op != 7);
    }
    
    //METODO PARA MENU DO MEDICO
    private void menuMedico(){
        int opc;
        do{
            v.imprimir("**************************************************************************************************************");
            v.imprimir("  ************ MENU ********************\n"
            +"          * 1- Adicionar Pacientes               *\n"
            +"          * 2- Alter dados Paciente              *\n"
            +"          * 3- Visualizar Paciente               *\n"
            +"          * 4- Marcar Consulta                   *\n"
            +"          * 5- Ver Salas reservadas              *\n"        
            +"          * 6-Terminar                           *\n"    
            +"          ****************************************\n");
            v.imprimir("*************************************************************************************************************");
            v.imprimir("Digite uma opcao: ");
            opc = v.validaInt("", 1, 6);
            switch(opc){
                case 1: a.adicionarInformacao(1);break;
                case 2: a.showInfo(1);break;
                case 6: System.exit(0);break;
            }
        }while( opc != 6);
    }
}
