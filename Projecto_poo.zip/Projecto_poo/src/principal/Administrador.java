
package principal;
import java.io.*;
public class Administrador extends Pessoa implements Serializable{
    //private Vector listaPaciente;
    //float tot =0;
    //private Vector listaDiari;
    //private Vector listaMedico;
    //private Vector listaAdim = new Vector();
    //MarcacaoConsulta mar = new MarcacaoConsulta();
    // Atributos
    private int senha;
    private int numAdministrador;
    
    //Construtores
    public Administrador(int id,String nome, String dataNas, String morada, String bi, int celular, char sexo, int numAdmin, int senha){
        super(id, nome, dataNas, morada, bi, celular, sexo);
        this.numAdministrador = numAdmin;
        this.senha = senha;
    }
    
    public Administrador(){
        this(0,"", "", "", "", 0, ' ', 0, 0);
    }
    
    //Getters
    public int getNumAdministrador(){
        return numAdministrador;
    }
    
    public int getSenha(){
        return senha;
    }
    
    //METODO PARA INFORMACAO
    public String toString(){
        return super.toString()+"\n"+
                "Numero Administrador............................................: "+numAdministrador+"\n"+
                "\n........................................................................................\n";
    }
    
    /*public void adicAdim(){
        v.imprimir("******************************** Criando Adiministrador ****8*************************************");
        Administrador adm = new Administrador();
        listaAdim.addElement(adm);
        listaAdim.trimToSize();   
    }*/
    
    /*@Override
    public void adicMedico() {
        v.imprimir("******************************** Criando Medico ***********8*************************************");
        Medico med = new Medico();    
        listaMedico.addElement(med);
        listaMedico.trimToSize();   
    } */
    /*public String visualizaMedicos() { 
        if(listaMedico.isEmpty()){
        v.imprimir("A lista de medicos esta vazia!");
        }else{
        v.imprimir("******************************** Medicos cadatrados **********************************************");}
        String visualizar="";
        int numMed = listaMedico.size();     
        Medico temp;     
        for (int k=0;k<numMed; k++) {       
            temp = (Medico)listaMedico.elementAt(k);
            visualizar += temp.toString(); 
        }
        
        return visualizar;   
    } 
    @Override
    public void adicPaciente() {   
        v.imprimir("*************************** Adicionando Paciente ****************************************");
        Paciente pac = new Paciente();    
        listaPaciente.addElement(pac);
        listaPaciente.trimToSize();   
    } 
    @Override
    public String visualizaPaciente() {  
        if(listaPaciente.isEmpty()){
            v.imprimir("A lista de pacientes de pacientes esta vazia!");
        }else{
        v.imprimir("**************************** Pacintes Cadastrados **************************************");}
        String visualizar="";
        int numPac = listaPaciente.size();     
        Paciente temp;     
        for (int k=0;k<numPac; k++) {       
            temp = (Paciente)listaPaciente.elementAt(k);
            visualizar += temp.toString(); 
        }
        
        return visualizar;   
    } 
    @Override
    public void alaterarDadoMedico(){
        v.imprimir("****************************** Alterando dados Do medico ************************************************");
        Medico medi;
         String res = "n";
         boolean ab = false;
        
        do{
            int procuraCod = v.validaInt("Digite o numero do Medico que pretende alterar os dados",1, 100);

            for(int y = 0; y<listaMedico.size(); y++){
                medi = (Medico)listaMedico.elementAt(y);
                if(procuraCod== medi.getNumMedico()){
                    listaMedico.remove(medi);
                    Medico med = new Medico(); 
                    listaMedico.add(y, med);
                   ab = true;
                }
            }
            if (ab == false){
                System.out.println("Numero nao encontrado!");
                //res = v.validaString("Deseja voltar a tentar? ", 1,2);
            }
        }while(res == "s");
    
    }
    @Override
    public void alaterarDadoPaciente(){
        v.imprimir("****************************** Alterando dados Do Paciente ************************************************");
        Paciente pacie;
        String resp="N";
        boolean ab = false;
        
        do{
            int procuraCod = v.validaInt("Digite o numero do Paciente que pretende alterar os dados",1, 100);

            for(int y = 0; y<listaPaciente.size(); y++){
                pacie = (Paciente)listaPaciente.elementAt(y);
                if(procuraCod== pacie.getNumPaciente()){
                    listaPaciente.remove(pacie);
                    Paciente pac = new Paciente(); 
                    listaPaciente.add(y, pac);
                    ab = true;
                }
            }
            if (ab == false){
                System.out.println("Numero nao encontrado!");
                //resp = v.validaString("Deseja voltar a tentar?[S/N] ",1,3);
            }
        }while(resp == "S");
    
    }
    @Override
    public void marcaConsulta(){
      
        
        mar.marca(listaMedico, listaPaciente);
        mar.visualizarSectoresResevados();
        
    }
    
    @Override
    public void imprSectores(){
        v.imprimir(mar.visualizarSectoresResevados());
    }
    @Override
    public void imprSala(){
        v.imprimir(mar.visualizarSalasResevados());
    }
    @Override
    public void imprimirTotal(){
        v.imprimir("Total das diaria: "+"\n");
        mar.TotalDiarias();
    }*/
   
}
